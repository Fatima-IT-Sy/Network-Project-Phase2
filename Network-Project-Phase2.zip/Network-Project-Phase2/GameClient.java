import java.io.*;
import java.net.*;
import javax.swing.SwingUtilities;

public class GameClient {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private MessageListener listener;
    private volatile boolean isRunning = true; 

    public interface MessageListener {
        void onMessageReceived(String msg);
    }

    public GameClient(String host, int port, MessageListener listener) {
        this.listener = listener;
        
        new Thread(() -> {
            try {
                this.socket = new Socket(host, port);
                this.out = new PrintWriter(socket.getOutputStream(), true);
                this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                String response;
                while (isRunning && (response = in.readLine()) != null) {
                    final String msg = response;
                    
                    if (this.listener != null) {
                        SwingUtilities.invokeLater(() -> {
                            this.listener.onMessageReceived(msg);
                        });
                    }
                }
            } catch (IOException e) {
                if (isRunning && this.listener != null) {
                    SwingUtilities.invokeLater(() -> {
                        this.listener.onMessageReceived("Connection Lost");
                    });
                }
            } finally {
                disconnect();  
            }
        }).start();
    }

    public void sendMessage(String msg) {
        if (out != null) {
            out.println(msg);
            out.flush(); 
        }
    }

    // for the disconnect after the player close the frame
    public void disconnect() {
        isRunning = false;
        try {
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException e) {
            System.err.println(" closing client socket: " + e.getMessage());
        }
    }
}