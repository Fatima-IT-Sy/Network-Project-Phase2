import java.io.*;
import java.net.*;
import java.util.List;

public class ClientHandler implements Runnable {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private Player player;
    private GameSession session; 

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            
            GameServer.addClientWriter(out);

            String request;
            // continuous loop to listen for client requests
            while ((request = in.readLine()) != null) {
                handleProtocol(request);
            }
        } catch (IOException e) {
            System.out.println("Connection lost with a player");
        } finally {
            cleanUp();
        }
    }

    private void handleProtocol(String request) {
        String[] parts = request.split(":", 2);
        String command = parts[0];

        switch (command) {
            case "LOGIN":
                String name = (parts.length > 1 && !parts[1].isEmpty()) ? parts[1] : "Agent";
                player = new Player(name);
                GameServer.playerManager.addPlayer(player);
                GameServer.registerPlayer(player, out, this);
                GameServer.broadcastGlobal("PLAYERS_LIST:" + GameServer.playerManager.getConnectedNames());
                break;

            case "PAIR_REQUEST":
                if (player != null) {
                    GameServer.playerManager.addToWaiting(player);
                    GameServer.broadcastGlobal("ROOM_LIST:" + GameServer.playerManager.getWaitingNames());

                    int count = GameServer.playerManager.getWaitingCount();
                    
                    if (count >= 2 && count < 4 && !GameServer.playerManager.isTimerRunning()) {
                        GameServer.playerManager.startTimer(30, () -> {
                            List<Player> players = GameServer.playerManager.getAllWaitingPlayers();
                            if (players.size() >= 2) prepareGame(players);
                        });
                    }
                    
                    List<Player> readyPlayers = GameServer.playerManager.tryFormingRoom();
                    if (readyPlayers != null) {
                        GameServer.playerManager.stopTimer();
                        prepareGame(readyPlayers);
                    }
                }
                break;

            case "SUBMIT_ANSWER":
                // Forward the answer to the active game session for validation
                if (player != null && session != null) {
                    String answer = (parts.length > 1) ? parts[1] : "";
                    session.checkAnswer(player, answer);
                }
                break;

            case "LEAVE_GAME":
                cleanUp();
                break;
        }
    }

    public void sendMessage(String msg) {
        if (out != null) {
            out.println(msg);
            out.flush();
        }
    }

    public void setSession(GameSession session) {
        this.session = session;
    }
    // initializes a new GameSession and binds handlers to it
    private void prepareGame(List<Player> players) {
        GameSession newSession = new GameSession(players);
        
        for (Player p : players) {
            ClientHandler handler = GameServer.playerHandlers.get(p);
            if (handler != null) {
                handler.setSession(newSession);
            }
        }
        
        newSession.startSession();
        GameServer.broadcastGlobal("ROOM_LIST:" + GameServer.playerManager.getWaitingNames());
    }

    private void cleanUp() {
        if (player != null) {
            GameServer.unregisterPlayer(player);
            GameServer.playerManager.removePlayer(player.getUsername());
            GameServer.broadcastGlobal("PLAYERS_LIST:" + GameServer.playerManager.getConnectedNames());
            GameServer.broadcastGlobal("ROOM_LIST:" + GameServer.playerManager.getWaitingNames());
        }
        GameServer.removeClient(out);
        try { socket.close(); } catch (IOException e) {}
    }
}