import javax.swing.*;
import java.awt.*;

public class LeaderboardFrame extends JFrame {
    private DefaultListModel<String> scoresModel = new DefaultListModel<>();
    private JFrame lobbyFrame; // مرجع لحفظ نسخة اللوبي وإعادة إحيائها

    public LeaderboardFrame(JFrame lobby) {
        this.lobbyFrame = lobby;

        // إعدادات النافذة
        setTitle("FINAL SCORES");
        setSize(450, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(10, 10, 10));
        setLayout(new BorderLayout(15, 15));

        JLabel titleLabel = new JLabel("RANKING", SwingConstants.CENTER);
        titleLabel.setForeground(Color.CYAN);
        titleLabel.setFont(new Font("Monospaced", Font.BOLD, 30));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        add(titleLabel, BorderLayout.NORTH);

        // قائمة النتائج
        JList<String> scoresList = new JList<>(scoresModel);
        scoresList.setBackground(new Color(20, 20, 20));
        scoresList.setForeground(new Color(0, 255, 65));
        scoresList.setFont(new Font("Monospaced", Font.BOLD, 18));
        
        JScrollPane scroll = new JScrollPane(scoresList);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 65), 1));
        add(scroll, BorderLayout.CENTER);

        JButton backBtn = new JButton("RETURN TO LOBBY");
        backBtn.setBackground(new Color(0, 40, 0));
        backBtn.setForeground(new Color(0, 255, 65));
        backBtn.setFont(new Font("Monospaced", Font.BOLD, 16));
        backBtn.setFocusPainted(false);
        backBtn.setPreferredSize(new Dimension(0, 60));
        
        backBtn.addActionListener(e -> {
            if (lobbyFrame != null) {
                if (lobbyFrame instanceof GameFrame) {
                    ((GameFrame) lobbyFrame).resetLobbyUI();
                }
                lobbyFrame.setVisible(true); // إظهار اللوبي بعد ما ينتهون من القيم
            }
            this.dispose(); 
        });

        JPanel btnPanel = new JPanel(new BorderLayout());
        btnPanel.setOpaque(false);
        btnPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
        btnPanel.add(backBtn, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }

    public void setFinalScores(String[] scores) {
        SwingUtilities.invokeLater(() -> {
            scoresModel.clear();
            for (String s : scores) {
                if (!s.trim().isEmpty()) {
                    scoresModel.addElement(">> " + s.trim());
                }
            }
        });
    }
}