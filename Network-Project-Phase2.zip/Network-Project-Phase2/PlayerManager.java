import java.util.*;
import java.util.concurrent.*;

public class PlayerManager {
    private final Map<String, Player> activePlayers = new ConcurrentHashMap<>();
    private final Queue<Player> waitingQueue = new ConcurrentLinkedQueue<>();
    
    private Timer gameTimer;
    private volatile boolean timerRunning = false;

    public void addPlayer(Player player) {
        activePlayers.put(player.getUsername().toLowerCase(), player);
    }

    public void addToWaiting(Player player) {
        if (!waitingQueue.contains(player)) {
            waitingQueue.add(player);
        }
    }

    public List<Player> tryFormingRoom() {
        if (waitingQueue.size() >= 4) {
            List<Player> roomPlayers = new ArrayList<>();
            for (int i = 0; i < 4; i++) {
                roomPlayers.add(waitingQueue.poll());
            }
            return roomPlayers;
        }
        return null; // الطابور لم يكتمل 
    }

    public String getConnectedNames() {
        return String.join(",", activePlayers.keySet());
    }

    public String getWaitingNames() {
        List<String> names = new ArrayList<>();
        for (Player p : waitingQueue) {
            names.add(p.getUsername());
        }
        return String.join(",", names);
    }

    public void removePlayer(String username) {
        if (username != null) {
            Player p = activePlayers.remove(username.toLowerCase());
            if (p != null) {
                waitingQueue.remove(p);
            }
        }
    }

    public int getWaitingCount() {
        return waitingQueue.size();
    }

    public List<Player> getAllWaitingPlayers() {
        return new ArrayList<>(waitingQueue);
    }

    public boolean isTimerRunning() {
        return timerRunning;
    }

    public void startTimer(int seconds, Runnable onFinish) {
        if (gameTimer != null) {
            gameTimer.cancel();
        }
        timerRunning = true;
        gameTimer = new Timer();
        
        gameTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                timerRunning = false;
                onFinish.run();
            }
        }, seconds * 1000L);
    }

    public void stopTimer() {
        if (gameTimer != null) {
            gameTimer.cancel();
            gameTimer = null;
        }
        timerRunning = false;
    }
}