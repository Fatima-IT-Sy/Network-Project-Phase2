import java.util.*;

public class GameSession {
    private List<Player> players;
    private String currentAnswer, currentCipher;
    private int timeLeft = 30;
    private Timer gameTimer;
    private boolean isActive = false;

    public GameSession(List<Player> players) { 
        this.players = players; 
    }

    public void startSession() {
        this.isActive = true;
        broadcastToSession("GAME_START");

        gameTimer = new Timer();
        
        gameTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                nextChallenge();
            }
        }, 1000);

        //timer
        gameTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                timeLeft--;
                if (timeLeft <= 0) {
                    stopSession();
                } else {
                    broadcastToSession("TIMER_UPDATE:" + timeLeft);
                }
            }
        }, 1000, 1000); 
    }

    public void nextChallenge() {
        if (!isActive) return;
        
        // gets the the word for cipher engine class
        String[] challenge = CipherEngine.generateChallenge();
        currentAnswer = challenge[0];
        currentCipher = challenge[1];
        
        broadcastToSession("NEW_CIPHER:" + currentCipher);
    }

    // synchronized==> يمنع تداخل إجابات اللاعبين في نفس اللحظة
    public synchronized void checkAnswer(Player p, String ans) {
        if (isActive && ans.equalsIgnoreCase(currentAnswer)) {
            p.addScore(timeLeft * 2);
            broadcastToSession("SCORE_UPDATE:" + p.getUsername() + ":" + p.getScore());
            nextChallenge(); 
        }
    }

    private void stopSession() {
        if (!isActive) return;
        isActive = false; 
        
        if (gameTimer != null) {
            gameTimer.cancel();
        }
        
        // ترتيب اللاعبين تنازلي حسب السكور
        players.sort((p1, p2) -> Integer.compare(p2.getScore(), p1.getScore()));
        
        StringBuilder res = new StringBuilder("GAME_RESULTS:");
        for (Player p : players) {
            res.append(p.getUsername()).append(": ").append(p.getScore()).append(" PTS,");
        }
        broadcastToSession(res.toString());
    }

    private void broadcastToSession(String m) {
        for (Player p : players) {
            java.io.PrintWriter out = GameServer.getWriterByPlayer(p);
            if (out != null) { 
                out.println(m); 
                out.flush(); 
            }
        }
    }
}