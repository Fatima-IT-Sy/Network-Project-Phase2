import java.util.Objects;

public class Player {
    private String username;
    private int score = 0;

    public Player(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void addScore(int points) {
        this.score += points;
    }

    public int getScore() {
        return score;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Player player = (Player) o;
        return username.equalsIgnoreCase(player.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username.toLowerCase());
    }
}