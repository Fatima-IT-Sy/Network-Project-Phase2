import javax.swing.*;
import java.awt.*;

public class GameRaceFrame extends JFrame {
    private JLabel timerLabel, cipherLabel, myScoreLabel;
    private JTextField inputField;
    private JButton submitBtn;
    private GameClient client;
    private String username;

    public GameRaceFrame(String username, GameClient client) {
        this.username = username;
        this.client = client;

        setTitle("IN PROGRESS: " + username.toUpperCase());
        setSize(850, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(10, 10, 10));
        setLayout(new BorderLayout(20, 20));

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(20, 30, 0, 30));

        timerLabel = new JLabel("TIME: 30s");
        timerLabel.setForeground(Color.WHITE);
        timerLabel.setFont(new Font("Monospaced", Font.BOLD, 22));

        myScoreLabel = new JLabel("SCORE: 0");
        myScoreLabel.setForeground(new Color(0, 255, 65));
        myScoreLabel.setFont(new Font("Monospaced", Font.BOLD, 22));

        header.add(timerLabel, BorderLayout.WEST);
        header.add(myScoreLabel, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        JPanel centerWrapper = new JPanel(new BorderLayout());
        centerWrapper.setOpaque(false);

        cipherLabel = new JLabel("STARTING...", SwingConstants.CENTER);
        cipherLabel.setForeground(Color.YELLOW);
        cipherLabel.setFont(new Font("Monospaced", Font.BOLD, 60));
        centerWrapper.add(cipherLabel, BorderLayout.CENTER);

        JLabel hintLabel = new JLabel("[ HINT: REVERSE THE TEXT TO DECRYPT ]", SwingConstants.CENTER);
        hintLabel.setForeground(new Color(150, 150, 150)); 
        hintLabel.setFont(new Font("Monospaced", Font.ITALIC, 18));
        hintLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0)); 
        centerWrapper.add(hintLabel, BorderLayout.SOUTH);

        add(centerWrapper, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 20));
        footer.setOpaque(false);

        inputField = new JTextField(20);
        inputField.setBackground(new Color(20, 20, 20));
        inputField.setForeground(Color.WHITE);
        inputField.setFont(new Font("Monospaced", Font.BOLD, 20));
        inputField.setCaretColor(Color.WHITE);
        inputField.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 65), 1));

        submitBtn = new JButton("DECRYPT");
        submitBtn.setBackground(new Color(0, 40, 0));
        submitBtn.setForeground(new Color(0, 255, 65));
        submitBtn.setFocusPainted(false);
        submitBtn.setPreferredSize(new Dimension(130, 40));

        footer.add(inputField);
        footer.add(submitBtn);
        add(footer, BorderLayout.SOUTH);

        submitBtn.addActionListener(e -> sendAnswer());
        inputField.addActionListener(e -> sendAnswer());
    }

    private void sendAnswer() {
        String answer = inputField.getText().trim();
        if (!answer.isEmpty()) {
            client.sendMessage("SUBMIT_ANSWER:" + answer);
            inputField.setText("");
        }
    }

    public void updateCipher(String newCipher) {
        SwingUtilities.invokeLater(() -> cipherLabel.setText(newCipher));
    }

    public void updateTimer(String time) {
        SwingUtilities.invokeLater(() -> {
            timerLabel.setText("TIME: " + time + "s");
            if (Integer.parseInt(time) <= 5) timerLabel.setForeground(Color.RED);
            else timerLabel.setForeground(Color.WHITE);
        });
    }

    public void updateScore(String score) {
        SwingUtilities.invokeLater(() -> myScoreLabel.setText("SCORE: " + score));
    }
}