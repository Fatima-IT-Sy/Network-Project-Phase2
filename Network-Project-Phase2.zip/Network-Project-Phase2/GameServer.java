import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameServer {
    private static final int PORT = 12345;
    
    public static PlayerManager playerManager = new PlayerManager();
    public static final Map<Player, PrintWriter> playerPrintWriters = new ConcurrentHashMap<>();
    public static final Map<Player, ClientHandler> playerHandlers = new ConcurrentHashMap<>(); 
    // قائمة عامة للبرودكاست 
    public static final List<PrintWriter> allWriters = Collections.synchronizedList(new ArrayList<>());

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("SERVER ACTIVE");

            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(new ClientHandler(socket)).start();
            }
        } catch (IOException e) {
            System.err.println("SERVER ERROR: " + e.getMessage());
        }
    }

    public static PrintWriter getWriterByPlayer(Player player) {
        return playerPrintWriters.get(player);
    }

    public static void broadcastGlobal(String message) {
        synchronized (allWriters) {
            for (PrintWriter writer : allWriters) {
                writer.println(message);
                writer.flush();
            }
        }
    }

    public static void registerPlayer(Player p, PrintWriter out, ClientHandler handler) {
        playerPrintWriters.put(p, out);
        playerHandlers.put(p, handler); 
        if (!allWriters.contains(out)) {
            allWriters.add(out);
        }
    }

    // remove the player when gets disconnect 
    public static void unregisterPlayer(Player p) {
        if (p != null) {
            playerPrintWriters.remove(p);
            playerHandlers.remove(p);
        }
    }

    public static void addClientWriter(PrintWriter out) {
        if (!allWriters.contains(out)) {
            allWriters.add(out);
        }
    }

    public static void removeClient(PrintWriter out) {
        allWriters.remove(out);
    }
}