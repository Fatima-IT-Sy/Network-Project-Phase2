import java.util.Random;

public class CipherEngine {
    
    // the words list
    private static final String[] WORDS = {
        "DATABASE", "NETWORK", "ENCRYPTION", "SOCKET", 
        "SECURITY", "PROTOCOL", "COMPUTING", "BYTECODE",
        "FIREWALL", "SERVER", "CLIENT", "ROUTER",
        "MALWARE", "PHISHING", "HACKER", "SYSTEM"
    };

    private static final Random RANDOM = new Random();

    public static String[] generateChallenge() {
        String original = WORDS[RANDOM.nextInt(WORDS.length)];
        String encoded = reverseText(original); 
        
        return new String[]{original, encoded};
    }

    private static String reverseText(String text) {
        return new StringBuilder(text).reverse().toString();
    }

    public static boolean validate(String userInput, String correctAnswer) {
        if (userInput == null) return false;
        return userInput.trim().equalsIgnoreCase(correctAnswer.trim());
    }
}