import javax.swing.*;
import java.awt.*;

public class GameFrame extends JFrame implements GameClient.MessageListener {
    private GameClient client;
    private String username;
    private GameRaceFrame raceFrame; 

    private DefaultListModel<String> allPlayersModel = new DefaultListModel<>();
    private DefaultListModel<String> waitingRoomModel = new DefaultListModel<>();
    private JButton joinBtn;
    private JLabel statusLabel;

    public GameFrame(String username) {
        this.username = username;
        setTitle("Cipher Race - Lobby: " + username);
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(10, 10, 10));
        setLayout(new BorderLayout(20, 20));

        // الهيدر
        statusLabel = new JLabel( username.toUpperCase());
        statusLabel.setForeground(new Color(0, 255, 65));
        statusLabel.setFont(new Font("Monospaced", Font.BOLD, 18));
        statusLabel.setHorizontalAlignment(JLabel.CENTER);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        add(statusLabel, BorderLayout.NORTH);

        // منطقة القوائم المتصلين وغرفة الانتظار
        JPanel listsPanel = new JPanel(new GridLayout(1, 2, 25, 0));
        listsPanel.setOpaque(false);
        listsPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        listsPanel.add(createListPanel("CONNECTED PLAYERS", new JList<>(allPlayersModel)));
        listsPanel.add(createListPanel("WAITING ROOM", new JList<>(waitingRoomModel)));
        add(listsPanel, BorderLayout.CENTER);

        // زر الانضمام لغرفة الانتظار
        joinBtn = new JButton("JOIN WAITING ROOM");
        joinBtn.setBackground(new Color(0, 40, 0));
        joinBtn.setForeground(new Color(0, 255, 65));
        joinBtn.setFont(new Font("Monospaced", Font.BOLD, 16));
        joinBtn.setFocusPainted(false);
        joinBtn.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 65), 1));
        joinBtn.setPreferredSize(new Dimension(0, 50));
        
        JPanel btnPanel = new JPanel(new BorderLayout());
        btnPanel.setOpaque(false);
        btnPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
        btnPanel.add(joinBtn, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);

        client = new GameClient("localhost", 12345, this);
        
        Timer t = new Timer(500, e -> client.sendMessage("LOGIN:" + username));
        t.setRepeats(false);
        t.start();

        joinBtn.addActionListener(e -> {
            client.sendMessage("PAIR_REQUEST");
            setWaitingStatus();
        });
    }

    //it lets the player can go back to lobby after the game
    public void resetLobbyUI() {
        joinBtn.setEnabled(true);
        joinBtn.setText("JOIN WAITING ROOM");
        statusLabel.setText(username.toUpperCase());
        statusLabel.setForeground(new Color(0, 255, 65));
        raceFrame = null; 
    }

    private JPanel createListPanel(String title, JList<String> list) {
        JPanel p = new JPanel(new BorderLayout(5, 5));
        p.setOpaque(false);
        JLabel lbl = new JLabel(title);
        lbl.setForeground(Color.GRAY);
        p.add(lbl, BorderLayout.NORTH);
        list.setBackground(new Color(20, 20, 20));
        list.setForeground(new Color(0, 255, 65));
        JScrollPane scroll = new JScrollPane(list);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(40, 40, 40), 1));
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    private void setWaitingStatus() {
        joinBtn.setEnabled(false);
        joinBtn.setText("SEARCHING FOR TARGETS...");
        statusLabel.setText("MATCHING PROCESS...");
        statusLabel.setForeground(Color.ORANGE);
    }

    @Override
    public void onMessageReceived(String msg) {
        SwingUtilities.invokeLater(() -> {
            if (msg.startsWith("PLAYERS_LIST:")) {
                allPlayersModel.clear();
                String content = msg.substring(13).trim();
                if (!content.isEmpty()) {
                    for (String s : content.split(",")) allPlayersModel.addElement("> " + s.trim());
                }
            } 
            // updating wating room
            else if (msg.startsWith("ROOM_LIST:")) {
                waitingRoomModel.clear();
                String content = msg.substring(10).trim();
                if (!content.isEmpty()) {
                    for (String s : content.split(",")) waitingRoomModel.addElement("READY: " + s.trim());
                }
            } 
            // moving to the race frame
            else if (msg.startsWith("GAME_START")) {
                if (raceFrame == null) {
                    raceFrame = new GameRaceFrame(username, client);
                }
                raceFrame.setVisible(true);
                this.setVisible(false); 
            } 
            else if (msg.startsWith("NEW_CIPHER:") && raceFrame != null) {
                raceFrame.updateCipher(msg.substring(11));
            } 
            else if (msg.startsWith("TIMER_UPDATE:") && raceFrame != null) {
                raceFrame.updateTimer(msg.substring(13));
            } 

            else if (msg.startsWith("SCORE_UPDATE:") && raceFrame != null) {
                String[] data = msg.split(":");
                if (data.length >= 3 && data[1].equalsIgnoreCase(username)) {
                    raceFrame.updateScore(data[2]);
                }
            } 
            else if (msg.startsWith("GAME_RESULTS:")) {
                String[] rankings = msg.substring(13).split(",");
                LeaderboardFrame board = new LeaderboardFrame(this); // تمرير اللوبي للعودة له
                board.setFinalScores(rankings);
                board.setVisible(true);
                //so the player can go back to lobby after the game
                if (raceFrame != null) raceFrame.dispose();
            }
        });
    }
}